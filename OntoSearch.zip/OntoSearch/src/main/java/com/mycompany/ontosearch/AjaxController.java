/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ontosearch;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author Whatever
 */
@WebServlet("/AjaxController")
public class AjaxController extends HttpServlet {

    Controller controller = Controller.getInstance();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");

        if (request.getParameter("questionField") != null) {

            String qField = request.getParameter("questionField");
            try {

                if ("".equals(qField.trim())) {
                    return;
                }

                String answer = controller.getSolrController().searchEngineAnswer(qField);

                answer = htmlCreation(answer);

                response.getWriter().print(answer);
            } catch (IOException ex) {
                System.out.println("Solr Connection failure.");
                response.getWriter().print("Connection Failure.");
            }
        }

    }


    private String htmlCreation(String answer) {

        ArrayList<String> EDAMToolArr = new ArrayList<>();
        ArrayList<String> SWOToolArr = new ArrayList<>();
        ArrayList<String> FreeTextToolArr = new ArrayList<>();
        ArrayList<String> HybridToolArr = new ArrayList<>();
        ArrayList<String> CommonToolArr = new ArrayList<>();

        TreeMap<Float, String[]> rankedCommon = new TreeMap<>();

        ArrayList<String> EDAMLinkArr = new ArrayList<>();
        ArrayList<String> SWOLinkArr = new ArrayList<>();
        ArrayList<String> FreeTextLinkArr = new ArrayList<>();
        ArrayList<String> HybridLinkArr = new ArrayList<>();
        ArrayList<String> CommonLinkArr = new ArrayList<>();

        String edam = StringUtils.substringBetween(answer, "<edam>", "</edam>");
        String swo = StringUtils.substringBetween(answer, "<swo>", "</swo>");
        String freeText = StringUtils.substringBetween(answer, "<freetext>", "</freetext>");
        String hybrid = StringUtils.substringBetween(answer, "<hybrid>", "</hybrid>");

        Pattern p = Pattern.compile(Pattern.quote("<tool>") + "(.*?)" + Pattern.quote("</tool>"));
        Matcher mEDAM = p.matcher(edam);
        Matcher mSWO = p.matcher(swo);
        Matcher mFreeText = p.matcher(freeText);
        Matcher mHybrid = p.matcher(hybrid);

        Pattern p2 = Pattern.compile(Pattern.quote("<link>") + "(.*?)" + Pattern.quote("</link>"));
        Matcher mEDAMLink = p2.matcher(edam);
        Matcher mSWOLink = p2.matcher(swo);
        Matcher mFreeTextLink = p2.matcher(freeText);
        Matcher mHybridLink = p2.matcher(hybrid);

        int notFound = 0;

        while (notFound < 4) {

            notFound = 0;

            if (mEDAM.find() && mEDAMLink.find()) {
                EDAMToolArr.add(mEDAM.group(1));
                EDAMLinkArr.add(mEDAMLink.group(1));
            } else {
                notFound++;
            }
            if (mSWO.find() && mSWOLink.find()) {
                SWOToolArr.add(mSWO.group(1));
                SWOLinkArr.add(mSWOLink.group(1));
            } else {
                notFound++;
            }
            if (mFreeText.find() && mFreeTextLink.find()) {
                FreeTextToolArr.add(mFreeText.group(1));
                FreeTextLinkArr.add(mFreeTextLink.group(1));
            } else {
                notFound++;
            }
            if (mHybrid.find() && mHybridLink.find()) {
                HybridToolArr.add(mHybrid.group(1));
                HybridLinkArr.add(mHybridLink.group(1));
            } else {
                notFound++;
            }
        }

        int maxArrSize = EDAMToolArr.size();
        if (SWOToolArr.size() > maxArrSize) {
            maxArrSize = SWOToolArr.size();
        }
        if (FreeTextToolArr.size() > maxArrSize) {
            maxArrSize = FreeTextToolArr.size();
        }
        if (HybridToolArr.size() > maxArrSize) {
            maxArrSize = HybridToolArr.size();
        }

        for (int i = 0; i < EDAMToolArr.size(); i++) {

            if (SWOToolArr.contains(EDAMToolArr.get(i)) && FreeTextToolArr.contains(EDAMToolArr.get(i)) && HybridToolArr.contains(EDAMToolArr.get(i))) {

                //TreeMap <Avg Rank,  <Tool, Link>> (sorted by Avg Rank)
                float tempAvgRank = ((int) (EDAMToolArr.indexOf(EDAMToolArr.get(i)) + SWOToolArr.indexOf(EDAMToolArr.get(i)) + FreeTextToolArr.indexOf(EDAMToolArr.get(i)) + HybridToolArr.indexOf(EDAMToolArr.get(i)) + 4) / 4);
                tempAvgRank += (float) i / maxArrSize; //avoids same avg rank possibility
                rankedCommon.put(tempAvgRank, new String[]{EDAMToolArr.get(i), EDAMLinkArr.get(i)});

            }

        }

        Iterator it = rankedCommon.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();

            String[] temp = (String[]) pair.getValue();
            CommonToolArr.add(temp[0]);
            CommonLinkArr.add(temp[1]);

            it.remove(); // avoids a ConcurrentModificationException
        }
        rankedCommon = null;

        answer = "<font size=\"2\" >"
                + "<table style=\"width:100%\">\n"
                + "  <tr>\n"
                + "    <th><center>&nbsp;EDAM Ontology&nbsp;</center></th>\n"
                + "    <th><center>Software Ontology</center></th> \n"
                + "    <th><center>&nbsp;&nbsp;Keyword-based&nbsp;&nbsp;</center></th>\n"
                + "    <th><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hybrid&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center></th>\n"
                + "    <th><center>&nbsp;Common Results&nbsp;</center></th>\n"
                + "  </tr>\n";

        boolean firstTime = true;

        for (int i = 0; (i < maxArrSize) || (firstTime && maxArrSize == 0); i++) {

            answer += "  <tr>\n";

            if (EDAMToolArr.size() > 0 && EDAMToolArr.size() > i) {
                answer += "    <td>&nbsp;&nbsp;<a href=\"" + EDAMLinkArr.get(i) + "\">" + EDAMToolArr.get(i) + "</a></td>\n";
            } else {
                if (firstTime) {
                    answer += "    <td>&nbsp;&nbsp;No Results.</td>\n";
                } else {
                    answer += "    <td></td>\n";
                }
            }

            if (SWOToolArr.size() > 0 && SWOToolArr.size() > i) {
                answer += "    <td>&nbsp;&nbsp;<a href=\"" + SWOLinkArr.get(i) + "\">" + SWOToolArr.get(i) + "</a></td>\n";
            } else {
                if (firstTime) {
                    answer += "    <td>&nbsp;&nbsp;No Results.</td>\n";
                } else {
                    answer += "    <td></td>\n";
                }
            }

            if (FreeTextToolArr.size() > 0 && FreeTextToolArr.size() > i) {
                answer += "    <td>&nbsp;&nbsp;<a href=\"" + FreeTextLinkArr.get(i) + "\">" + FreeTextToolArr.get(i) + "</a></td>\n";
            } else {
                if (firstTime) {
                    answer += "    <td>&nbsp;&nbsp;No Results.</td>\n";
                } else {
                    answer += "    <td></td>\n";
                }
            }
              if (HybridToolArr.size() > 0 && HybridToolArr.size() > i) {
                answer += "    <td>&nbsp;&nbsp;<a href=\"" + HybridLinkArr.get(i) + "\">" + HybridToolArr.get(i) + "</a></td>\n";
            } else {
                if (firstTime) {
                    answer += "    <td>&nbsp;&nbsp;No Results.</td>\n";
                } else {
                    answer += "    <td></td>\n";
                }
            }

            if (CommonToolArr.size() > 0 && CommonToolArr.size() > i) {
                answer += "    <td>&nbsp;&nbsp;<a href=\"" + CommonLinkArr.get(i) + "\">" + CommonToolArr.get(i) + "</a></td>\n";
            } else {
                if (firstTime) {
                    answer += "    <td>&nbsp;&nbsp;No Common Results.</td>\n";
                } else {
                    answer += "    <td></td>\n";
                }
            }

            answer += "  </tr>\n";

            firstTime = false;

        }

        answer += "</table>"
                + "</font>"
                + "<style>"
                + "table { border: none; border-collapse: collapse; table-layout: fixed; }\n"
                + "table td,th { border-left: 1px dashed #000; }\n"
                + "table th:first-child,td:first-child { border-left: none; }"
                + "</style>";

        return answer;
    }

}
