package com.mycompany.ontosearch.databaseControl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBController {

    private static DBController instance = null;

    private Connection conn = null;

    private DBController() {
    }

    /*
    Connects to DB 
    Returns connection
     */
    public Connection connect() {

        try {
            
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(
                    "jdbc:postgresql://127.0.0.1:5432/ontosearch",//dbname
                    "postgres",//username
                    "9450000");//password

        } catch (SQLException e) {

            System.out.println("Connection Failed! Check output console");
            e.printStackTrace();
            return null;

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return conn;
    }

    /*
        Disconnects from DB 
     */
    public void disconnect() {

        try {
            conn.close();
            conn = null;
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static DBController getInstance() {
        if (instance == null) {
            instance = new DBController();
        }

        return instance;
    }

}
