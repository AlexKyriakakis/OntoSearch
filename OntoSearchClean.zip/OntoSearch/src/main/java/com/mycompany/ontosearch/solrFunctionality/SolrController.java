package com.mycompany.ontosearch.solrFunctionality;

import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.util.*;
import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.xml.sax.SAXException;
import com.mycompany.ontosearch.databaseControl.DBController;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;
import org.apache.solr.client.solrj.SolrRequest.METHOD;
import org.apache.solr.client.solrj.impl.HttpSolrClient.RemoteSolrException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class SolrController {

    private static SolrController instance = null;

    private final String xmlPath = "C:/Users/akyri/Desktop/Ptyxiaki/texts.xml";
    DBController DBControl = null;
    ArrayList<String> errors = new ArrayList<>();
    int answersPerOntology = 13;

    private ArrayList<String> idPerDocEDAM = null;
    private ArrayList<String> urlPerDocEDAM = null;
    private ArrayList<List> docIDsPerDocEDAM = null;
    private ArrayList<List> docScoresPerDocEDAM = null;

    private ArrayList<String> idPerDocSWO = null;
    private ArrayList<String> urlPerDocSWO = null;
    private ArrayList<List> docIDsPerDocSWO = null;
    private ArrayList<List> docScoresPerDocSWO = null;

    private SolrController() throws IOException, SolrServerException, SAXException {

        loadData();
    }

    /*
        Finds best answer(s) from db and for each Ontology
        Returns it in html-like format
     */
    public String searchEngineAnswer(String query) {
        query = solrSymbolsReplace(query);
        String EDAMAnswer = "";
        String solrServer = "http://localhost:8983/solr/edam";
        try {
            EDAMAnswer = EDAMAnswer(query, solrServer);
        } catch (SolrServerException | IOException ex) {
            Logger.getLogger(SolrController.class.getName()).log(Level.SEVERE, null, ex);
        }
        String SWOAnswer = "";
        solrServer = "http://localhost:8983/solr/swo";
        try {
            SWOAnswer = SWOAnswer(query, solrServer);
        } catch (SolrServerException | IOException ex) {
            Logger.getLogger(SolrController.class.getName()).log(Level.SEVERE, null, ex);
        }
        String biotoolsAnswer = "";
        solrServer = "http://localhost:8983/solr/biotools";
        try {
            biotoolsAnswer = biotoolsAnswer(query, solrServer);
        } catch (SolrServerException | IOException ex) {
            Logger.getLogger(SolrController.class.getName()).log(Level.SEVERE, null, ex);
        }
        String hybridAnswer = "";
        solrServer = "http://localhost:8983/solr/hybrid";
        try {
            hybridAnswer = hybridAnswer(query, solrServer);
        } catch (SolrServerException | IOException ex) {
            Logger.getLogger(SolrController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "<edam>" + EDAMAnswer + "</edam>" + "<swo>" + SWOAnswer + "</swo>" + "<freetext>" + biotoolsAnswer + "</freetext> " + "<hybrid>" + hybridAnswer + "</hybrid>";

    }

    //to be continued
    private String translate(String query) {

        return query;
    }

    /*
        Finds best answer(s) from EDAM
        Returns it in html-like format
     */
    private String EDAMAnswer(String query, String solrServer) throws IOException, SolrServerException {

        QueryResponse response = runQuery(query, "edam", solrServer);
        SolrDocumentList questionSolrResponse = response.getResults();

        int scores[] = new int[idPerDocEDAM.size()];
        ArrayList<Integer> pointers = new ArrayList<>();

        //scoring
        for (int i = 0; i < idPerDocEDAM.size(); i++) {

            int tempScore = 0;

            for (SolrDocument result : questionSolrResponse) {

                if (Float.parseFloat(result.getFieldValue("score").toString()) > 0) {
                    if (docIDsPerDocEDAM.get(i).contains(result.getFieldValue("uri").toString().replace("http://edamontology.org/", ""))) {
                        tempScore += (int) (Float.parseFloat(docScoresPerDocEDAM.get(i).get(docIDsPerDocEDAM.get(i).indexOf(result.getFieldValue("uri").toString().replace("http://edamontology.org/", ""))).toString()) + (Float.parseFloat(result.getFieldValue("score").toString())) / 2);
                    }
                }
            }

            //performance improvements
            if (tempScore > 0) {
                scores[i] = tempScore;
                pointers.add(i);
            }

        }

        int[] maxPointers;

        //keep pointers of largest N scores
        maxPointers = findNLargest(scores, answersPerOntology, pointers);

        String result = "";

        //get answers from pointers
        if (maxPointers != null && maxPointers[0] > 0) {
            result = "<tool>" + idPerDocEDAM.get(maxPointers[0]) + "</tool><link>" + urlPerDocEDAM.get(maxPointers[0]) + "</link>";

            for (int i = 1; i < maxPointers.length; i++) {
                if (maxPointers[i] > 0) {
                    result += "," + "<tool>" + idPerDocEDAM.get(maxPointers[i]) + "</tool><link>" + urlPerDocEDAM.get(maxPointers[i]) + "</link>";
                }
            }
        }
        if (maxPointers != null && maxPointers[0] > 0) {
            return result;
        } else {
            return ("No Results.");
        }
    }

    /*
        Finds best answer(s) from SWO
        Returns it in html-like format
     */
    private String SWOAnswer(String query, String solrServer) throws IOException, SolrServerException {

        QueryResponse response = runQuery(query, "swo", solrServer);
        SolrDocumentList questionSolrResponse = response.getResults();

        int scores[] = new int[idPerDocSWO.size()];
        ArrayList<Integer> pointers = new ArrayList<>();

        //scoring
        //for each tool, the average score of the terms that match with both the tool and the user’s query is saved for each tool
        for (int i = 0; i < idPerDocSWO.size(); i++) {

            int tempScore = 0;

            for (SolrDocument result : questionSolrResponse) {

                if (Float.parseFloat(result.getFieldValue("score").toString()) > 0) {
                    if (docIDsPerDocSWO.get(i).contains(result.getFieldValue("id"))) {
                        //  System.out.println("in");
                        tempScore += (int) (Float.parseFloat(docScoresPerDocSWO.get(i).get(docIDsPerDocSWO.get(i).indexOf(result.getFieldValue("id"))).toString()) + (Float.parseFloat(result.getFieldValue("score").toString())) / 2);
                    }

                }
            }
            if (tempScore > 0) {
                scores[i] = tempScore;
                pointers.add(i);
            }

        }

        int[] maxPointers;

        //keep pointers of largest N scores
        maxPointers = findNLargest(scores, answersPerOntology, pointers);

        String result = "";

        //get answers from pointers
        if (maxPointers != null && maxPointers[0] > 0) {
            result = "<tool>" + idPerDocSWO.get(maxPointers[0]) + "</tool><link>" + urlPerDocSWO.get(maxPointers[0]) + "</link>";

            for (int i = 1; i < maxPointers.length; i++) {
                if (maxPointers[i] > 0) {
                    result += "," + "<tool>" + idPerDocSWO.get(maxPointers[i]) + "</tool><link>" + urlPerDocSWO.get(maxPointers[i]) + "</link>";
                }

            }
        }

        if (maxPointers != null && maxPointers[0] > 0) {
            return result;
        } else {
            return ("No Results.");
        }
    }

    /*
        Finds best answer(s) from biotools free text
        Returns it in html-like format
     */
    private String biotoolsAnswer(String query, String solrServer) throws IOException, SolrServerException {

        QueryResponse response = runQuery(query, "biotools", solrServer);
        SolrDocumentList questionSolrResponse = response.getResults();

        String answer = "";
        boolean firstTime = true;
        for (SolrDocument result : questionSolrResponse) {

            String name = result.getFieldValue("name").toString();
            String link = result.getFieldValue("homepage").toString();

            name = name.replace("[", "");
            name = name.replace("]", "");
            link = link.replace("[", "");
            link = link.replace("]", "");

            if (firstTime) {
                firstTime = false;
            } else {
                answer += ",";
            }

            answer += "<tool>" + name + "</tool><link>" + link + "</link>";

        }

        if (!answer.isEmpty()) {
            return answer;
        } else {
            return ("No Results.");
        }
    }

    /*
        Finds best answer(s) from hybrid
        Returns it in html-like format
     */
    private String hybridAnswer(String query, String solrServer) throws IOException, SolrServerException {

        QueryResponse response = runQuery(query, "hybrid", solrServer);
        SolrDocumentList questionSolrResponse = response.getResults();

        String answer = "";
        boolean firstTime = true;
        for (SolrDocument result : questionSolrResponse) {

            String name = result.getFieldValue("name").toString();
            String link = result.getFieldValue("homepage").toString();

            name = name.replace("[", "");
            name = name.replace("]", "");
            link = link.replace("[", "");
            link = link.replace("]", "");

            if (firstTime) {
                firstTime = false;
            } else {
                answer += ",";
            }

            answer += "<tool>" + name + "</tool><link>" + link + "</link>";

        }

        if (!answer.isEmpty()) {
            return answer;
        } else {
            return ("No Results.");
        }
    }

    /*
        Runs solr query 
        Returns solr response
     */
    private QueryResponse runQuery(String queryQ, String ontology, String solrServer) throws IOException, SolrServerException {

        SolrClient solr = new HttpSolrClient.Builder(solrServer).build();
        SolrQuery params = new SolrQuery();

        switch (ontology) {
            case "edam": {
                //field weights
                params.setQuery("definition:(" + queryQ + ")^" + 5
                        + " OR uri:(" + queryQ + ")^" + 1
                        + " OR name:(" + queryQ + ")^" + 2);
                params.setStart(0);
                params.setRows(22);
                break;
            }
            case "swo": {
                //field weights
                params.setQuery("id:(" + queryQ + ")^" + 1
                        + " OR description:(" + queryQ + ")^" + 10
                        + " OR label:(" + queryQ + ")^" + 4
                        + " OR comment:(" + queryQ + ")^" + 4);
                params.setStart(0);
                params.setRows(22);
                break;
            }
            case "biotools": {
                //field weights
                params.setQuery("description:(" + queryQ + ")^" + 2
                        + " OR name:(" + queryQ + ")^" + 1);
                params.setStart(0);
                params.setRows(answersPerOntology);
                break;
            }
            case "hybrid": {
                //field weights
                params.setQuery(""
                        + "description:(" + queryQ + ")^" + 50
                        + " OR name:(" + queryQ + ")^" + 25
                        + " OR edam1Description:(" + queryQ + ")^" + 10
                        + " OR edam2Description:(" + queryQ + ")^" + 10
                        + " OR edam3Description:(" + queryQ + ")^" + 10
                        + " OR edam4Description:(" + queryQ + ")^" + 10
                        + " OR edam5Description:(" + queryQ + ")^" + 10
                        + " OR swo1Description:(" + queryQ + ")^" + 10
                        + " OR swo2Description:(" + queryQ + ")^" + 10
                        + " OR swo3Description:(" + queryQ + ")^" + 10
                        + " OR swo4Description:(" + queryQ + ")^" + 10
                        + " OR swo5Description:(" + queryQ + ")^" + 10
                        + " OR edam1Term:(" + queryQ + ")^" + 7
                        + " OR edam2Term:(" + queryQ + ")^" + 7
                        + " OR edam3Term:(" + queryQ + ")^" + 7
                        + " OR edam4Term:(" + queryQ + ")^" + 7
                        + " OR edam5Term:(" + queryQ + ")^" + 7
                        + " OR swo1Term:(" + queryQ + ")^" + 7
                        + " OR swo2Term:(" + queryQ + ")^" + 7
                        + " OR swo3Term:(" + queryQ + ")^" + 7
                        + " OR swo4Term:(" + queryQ + ")^" + 7
                        + " OR swo5Term:(" + queryQ + ")^" + 7
                );
                params.setStart(0);
                params.setRows(answersPerOntology);
                break;
            }
        }

        params.setSort("score ", SolrQuery.ORDER.desc);

        QueryResponse rsp = solr.query(params, METHOD.POST);
        try {
            return rsp;
        } catch (RemoteSolrException e) {
            System.out.println(e);
            return null;
        }

    }

    /*
        Adds a backslash before every special symbol of Apache Solr. That way solr doesn't use it as a special symbol.
        Returns the String
     */
    private String solrSymbolsReplace(String query) {

        ArrayList<String> specialCharacters = new ArrayList<>(Arrays.asList("\\", "+", "-", "&&", "||", "!", "(", ")", "[", "]", "{", "}", "\"", "^", "~", "*", "?", ":", "/", "AND", "OR", "NOT"));

        for (int i = 0; i < specialCharacters.size(); i++) {
            query = query.replace(specialCharacters.get(i), ("\\" + specialCharacters.get(i)));
        }

        return query;
    }

    /*
        Loads data from DB.
     */
    private void loadData() {

        DBControl = DBController.getInstance();
        Connection conn = DBControl.connect();
        loadDataEDAM(conn);
        loadDataSWO(conn);

        DBControl.disconnect();
        DBControl = null;
    }

    /*
        Loads EDAM data from DB
     */
    private void loadDataEDAM(Connection conn) {
        Statement stmt = null;

        idPerDocEDAM = new ArrayList<>();
        urlPerDocEDAM = new ArrayList<>();
        docIDsPerDocEDAM = new ArrayList<>();
        docScoresPerDocEDAM = new ArrayList<>();

        try {
            stmt = conn.createStatement();

            try (ResultSet rs = stmt.executeQuery("SELECT * FROM solrresultsedam;")) {
                while (rs.next()) {
                    String name = rs.getString("name");
                    String url = rs.getString("url");
                    Array tempDocIDs = rs.getArray("solrdocids");
                    Array tempDocScores = rs.getArray("solrdocscores");
                    List<String> docIDs = Arrays.asList((String[]) tempDocIDs.getArray());
                    List<Integer> docScores = Arrays.asList((Integer[]) tempDocScores.getArray());

                    idPerDocEDAM.add(name);
                    urlPerDocEDAM.add(url);
                    docIDsPerDocEDAM.add(docIDs);
                    docScoresPerDocEDAM.add(docScores);

                }
            }
            stmt.close();

        } catch (SQLException e) {
        } finally {

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                }
            }
        }
    }

    /*
        Loads SWO data from DB
     */
    private void loadDataSWO(Connection conn) {
        Statement stmt = null;

        idPerDocSWO = new ArrayList<>();
        urlPerDocSWO = new ArrayList<>();
        docIDsPerDocSWO = new ArrayList<>();
        docScoresPerDocSWO = new ArrayList<>();

        try {
            stmt = conn.createStatement();

            try (ResultSet rs = stmt.executeQuery("SELECT * FROM solrresultsswo;")) {
                while (rs.next()) {
                    String name = rs.getString("name");
                    String url = rs.getString("url");
                    Array tempDocIDs = rs.getArray("solrdocids");
                    Array tempDocScores = rs.getArray("solrdocscores");
                    List<String> docIDs = Arrays.asList((String[]) tempDocIDs.getArray());
                    List<Integer> docScores = Arrays.asList((Integer[]) tempDocScores.getArray());

                    idPerDocSWO.add(name);
                    urlPerDocSWO.add(url);
                    docIDsPerDocSWO.add(docIDs);
                    docScoresPerDocSWO.add(docScores);

                }
            }
            stmt.close();

        } catch (SQLException e) {
        } finally {

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                }
            }
        }

    }

    /*
        Finds pointers of N largest elements
        Returns the pointers in String[]
     */
    static int[] findNLargest(int arr[], int maxNum, ArrayList<Integer> scorePointers) {

        if (scorePointers.isEmpty()) {
            return null;
        }

        /* There should be atleast two elements */
        if (scorePointers.size() < maxNum) {
            maxNum = scorePointers.size();
        }
        int[] largest = new int[maxNum];
        int[] pointers = new int[maxNum];

        for (int j = 0; j < largest.length; j++) {
            largest[j] = Integer.MIN_VALUE;
        }

        for (int h = 0; h < scorePointers.size(); h++) {
            /* If current element is smaller than
            first*/

            int i = scorePointers.get(h);

            int k = 0;
            for (int j = largest.length - k - 1; j >= 0; j--) {

                if (arr[i] > largest[k]) {
                    for (int p = largest.length - 1; p > k; p--) {

                        largest[p] = largest[p - 1];
                        pointers[p] = pointers[p - 1];

                    }
                    largest[k] = arr[i];
                    pointers[k] = i;
                    break;
                }
                k++;
            }

        }
        /*
        for (int j = 0; j < largest.length; j++) {
            System.out.println(j + " : " + largest[j] + " , pointer: " + pointers[j]);
        }
         */
        return pointers;

    }

  
    public static SolrController getInstance() throws IOException, SolrServerException, SAXException {
        if (instance == null) {
            instance = new SolrController();
        }

        return instance;
    }

    /*
         *
         * TEST CODES
         *
     */
    private void selectAllFromSolr() throws IOException, SolrServerException {

        String queryQ = "*:*";
        QueryResponse response = runQuery(queryQ, "edam", "http://localhost:8983/solr/edam");
        SolrDocumentList results = response.getResults();
        for (SolrDocument result : results) {

            System.out.println(result);
            System.out.println(result.getFieldValue("uri"));
            System.out.println("Score : " + Math.round((Float) result.get("score")));

        }

    }

    private void deleteAllFromSolr() throws IOException, SolrServerException {

        SolrClient solr = new HttpSolrClient.Builder("http://localhost:8983/solr/edam").build();
        //Deleting the documents from Solr
        solr.deleteByQuery("*");
        //Saving the document
        solr.commit();
        System.out.println("Documents deleted");

    }


}
