package com.mycompany.ontosearch.databaseControl;

import com.mycompany.ontosearch.Config;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBController {

    private static DBController instance = null;

    private Connection conn = null;

    private DBController() {
    }

    /*
    Connects to DB 
    Returns connection
     */
    public Connection connect() {

        
        String dbName = Config.getInstance().getDBName();
        String dbUsername = Config.getInstance().getDBUsername();
        String dbPassword = Config.getInstance().getDBPassword();

        System.out.println(dbName+" yo1");
        
        try {
            
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(dbName, dbUsername, dbPassword);

        } catch (SQLException e) {

            System.out.println("Connection Failed! Check output console");
            e.printStackTrace();
            return null;

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return conn;
    }

    /*
        Disconnects from DB 
     */
    public void disconnect() {

        try {
            conn.close();
            conn = null;
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static DBController getInstance() {
        if (instance == null) {
            instance = new DBController();
        }

        return instance;
    }

}
