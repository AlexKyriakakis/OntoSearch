package com.mycompany.ontosearch;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Alex
 */
public class Config {

    private static Config instance = null;

    //database name, user, pass
    static private String dbName;
    static private String dbUsername;
    static private String dbPassword;

    static {
        readXML();
    }

    public String getDBName() {
        return dbName;
    }

    public String getDBUsername() {
        return dbUsername;
    }

    public String getDBPassword() {
        return dbPassword;
    }

    static private void readXML() {

        try {

            File inputFile = new File("OntoSearch/config.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc;

            doc = dBuilder.parse(inputFile);

            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("config");

            Node nNode = nList.item(0);

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {

                Element eElement = (Element) nNode;

                dbName = eElement.getElementsByTagName("dbName").item(0).getTextContent();
                dbUsername = eElement.getElementsByTagName("dbUsername").item(0).getTextContent();
                dbPassword = eElement.getElementsByTagName("dbPassword").item(0).getTextContent();

            }

        } catch (SAXException | IOException | ParserConfigurationException ex) {
            Logger.getLogger(Config.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static Config getInstance() {
        if (instance == null) {
            instance = new Config();
        }
        return instance;
    }

}
