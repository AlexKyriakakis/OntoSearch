package com.mycompany.ontosearch;

import java.io.IOException;
import org.apache.solr.client.solrj.SolrServerException;
import org.xml.sax.SAXException;
import com.mycompany.ontosearch.solrFunctionality.SolrController;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Alex.
 */
public class Controller {

    private static Controller instance = null;

    public SolrController sC;

    private Controller() {

        try {
            sC = SolrController.getInstance();
        } catch (SAXException | IOException | SolrServerException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public SolrController getSolrController() {
        return sC;
    }

    public static Controller getInstance() {
        if (instance == null) {
            instance = new Controller();
        }

        return instance;
    }

}
