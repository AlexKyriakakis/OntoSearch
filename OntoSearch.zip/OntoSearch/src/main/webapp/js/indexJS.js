
function onLoadFunc() {

    window.SpeechRecognition = window.webkitSpeechRecognition;
    if (!('webkitSpeechRecognition' in window)) {
        $('.dropdown-toggle').prop('disabled', true);
        $('#myCheck').prop('disabled', true);
        var recordingSwitch = document.getElementById('myCheck');
        recordingSwitch.disabled = true;
    }
    
    $(document).on('keypress',function(e) {
    if(e.which === 13 && document.activeElement === document.getElementById('question_field'))  {
        searchFunc();
    }
});

}

function checkboxFunc() {

    var speechRecognizer;
    var qField = document.getElementById('question_field');
    var checkbox = document.getElementById('myCheck');

    if (checkbox.checked)
    {
        if ('webkitSpeechRecognition' in window) {
            speechRecognizer = new window.webkitSpeechRecognition();
            document.getElementById("micImg").src = "images/MicRecording.gif";//2aMc6v7A3AtwAYmkP3
            langOption = $('select[name=language] option:selected').text();
            $('.dropdown-toggle').prop('disabled', true);
            speechRecognizer.continous = true;
            speechRecognizer.interimResults = true;
            speechRecognizer.lang = langOption;
            speechRecognizer.start();
            qField.readOnly = true;
            var finalTranscripts = '';

            speechRecognizer.onresult = function (event) {
                var interimTranscripts = '';
                for (var i = 0; i < event.results.length; i++) {
                    var transcript = event.results[i][0].transcript;
                    transcript.replace("\n", "<br>");
                    if (event.results[i].isFinal) {
                        if (finalTranscripts !== "") {
                            finalTranscripts += " ";
                        }
                        finalTranscripts += transcript;
                    } else {
                        interimTranscripts += "(" + transcript + ")";
                    }
                }
                if (checkbox.checked) {
                    qField.value = finalTranscripts + interimTranscripts;
                }
                if (qField.focus() === false) {
                    qField.focus();
                }
            };

            speechRecognizer.onend = function () {
                if (recording) {
                    speechRecognizer.start();
                } else {
                    speechRecognizer.stop();
                }
            };

            speechRecognizer.onerror = function (event) {

            };

            recording = true;
        } else {
            checkbox.checked = false;
            qField.readOnly = false;
            if (qField.focus() === false) {
                qField.focus();
            }
            qField.value = "Your browser does not support speech recognition.";
        }
    } else {
        if ('webkitSpeechRecognition' in window) {
            document.getElementById("micImg").src = "images/MicNotRecording.png";
            recording = false;
            qField.readOnly = false;
            $('.dropdown-toggle').prop('disabled', false);
            speechRecognizer.stop();
        }
    }
}

function searchFunc() {
    var questionField = $('#question_field').val();
    
    if(document.getElementById('myCheck').checked){
        document.getElementById('myCheck').checked=false;
        checkboxFunc();
    }
    
    if (questionField.trim() === "") {
        return;
    }
    
    document.getElementById('question_field').blur();
    
    var searchBtn = document.getElementById('searchBtn');

    searchBtn.disabled = true;

    $.ajax({
        url: "AjaxController",
        type: "POST",
        data: {questionField: questionField},
        success: function (result) {

            searchBtn.disabled = false;
            var mymodal = $('#myModal');

            mymodal.find('.modal-body').html(result);
            mymodal.modal('show');
            //$("#myModal").modal({html: result});
        },
        onerror: function (result) {

            searchBtn.disabled = false;
            M.toast({html: "error"});
        }
    });

}

